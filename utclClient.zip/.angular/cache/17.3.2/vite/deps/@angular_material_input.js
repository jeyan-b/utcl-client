import {
  MAT_INPUT_VALUE_ACCESSOR,
  MatInput,
  MatInputModule,
  getMatInputUnsupportedTypeError
} from "./chunk-TGFR7EEE.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-5XAZFHPP.js";
import "./chunk-2V372IP7.js";
import "./chunk-RZV256WS.js";
import "./chunk-3D7KU3WO.js";
import "./chunk-6SOXR5QL.js";
import "./chunk-OTET3YRB.js";
import "./chunk-DBKINIGK.js";
import "./chunk-QKULIGGZ.js";
import "./chunk-J4B6MK7R.js";
export {
  MAT_INPUT_VALUE_ACCESSOR,
  MatError,
  MatFormField,
  MatHint,
  MatInput,
  MatInputModule,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatInputUnsupportedTypeError
};
//# sourceMappingURL=@angular_material_input.js.map
