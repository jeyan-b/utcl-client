import { Component } from '@angular/core';

@Component({
  selector: 'app-loi-details',
  templateUrl: './loi-details.component.html',
  styleUrl: './loi-details.component.scss'
})
export class LoiDetailsComponent {

}
