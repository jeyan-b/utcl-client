import { CommonConfigClass } from './CommonConfigClass';

export class ConfigurationData
 {


}
