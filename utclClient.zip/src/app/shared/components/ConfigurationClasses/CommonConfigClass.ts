export class CommonConfigClass {
  type: string;
  placeholder: string;
  controlName: string;
  isRequired: boolean;
  maxLength: number;
  minLength: number;
  hasRegex: string;

  constructor(){

  }
}
