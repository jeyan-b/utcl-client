export class ValidationClass {
    isRequired : boolean;
    maxLength : number;
    minLength : number;
    hasRegex : string;

    constructor(){

    }
}
