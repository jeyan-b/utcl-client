export interface SalesData{
    year:number;
    amount:number,
    colorcode:string

}