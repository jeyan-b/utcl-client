declare module 'stompjs';
declare module 'stockjs-client';
