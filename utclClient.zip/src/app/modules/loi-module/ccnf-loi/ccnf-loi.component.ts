import { Component, OnInit } from '@angular/core';
import { Title } from '@angular/platform-browser';
import { GlobalSharedService } from '../../../core/services/global-shared.service';
import { AppSettings } from '../../../app-constants/appSettings';
import { MatDialog } from '@angular/material/dialog';
import { LoiDetailsComponent } from '../../../shared/components/loi-details/loi-details.component';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Agency, Agreement, CcnfCommision } from '../model/agency';
import { LoiService } from '../service/loi.service';

@Component({
  selector: 'app-ccnf-loi',
  templateUrl: './ccnf-loi.component.html',
  styleUrls: ['./ccnf-loi.component.css'],
})
export class CcnfLoiComponent implements OnInit {
  xpandStatus: boolean = true;
  successNotification: boolean = false;
  failureNotification: boolean = false;
  isNextClicked: boolean = false;
  agencyForm: FormGroup;
  agreementForm: FormGroup;
  ccnfCommisionForm: FormGroup;
  selectedTab = new FormControl(0);
  isAgencyDataSaved: boolean = false;
  isAgreementDataSaved: boolean = false;
  isCCnFCommisionDataSaved: boolean = false;
  constructor(
    private titleSvc: Title,
    private globalSharedSrv: GlobalSharedService,
    private _dialog: MatDialog,
    private loiService: LoiService
  ) {
    this.titleSvc.setTitle(AppSettings.applicationName + '- CCNF-LOI');
    this.globalSharedSrv.pageTitle.next('CCNF LOI');
  }

  ngOnInit() {
    this.agencyForm = new FormGroup({
      agency_vendor: new FormControl('', Validators.required),
      agency_agencyName: new FormControl('', Validators.required),
      agency_state: new FormControl('', Validators.required),
      agency_region: new FormControl('', Validators.required),
      agency_depot: new FormControl('', Validators.required),
      agency_district: new FormControl('', Validators.required),
    });
    this.agreementForm = new FormGroup({
      agreement_startDate: new FormControl('', Validators.required),
      agreement_endDate: new FormControl('', Validators.required),
      agreement_billingCycle: new FormControl('', Validators.required),
    });
    this.ccnfCommisionForm = new FormGroup({
      ccnf_commisionRangeFrom: new FormControl('', Validators.required),
      ccnf_commisionRangeTo: new FormControl('', Validators.required),
    });
    this.agencyForm.statusChanges.subscribe((result) => {
      console.log(result);
      this.isAgencyDataSaved = false;
    });
    this.agreementForm.statusChanges.subscribe((result) => {
      console.log(result);
      this.isAgreementDataSaved = false;
    });
    this.ccnfCommisionForm.statusChanges.subscribe((result) => {
      console.log(result);
      this.isCCnFCommisionDataSaved = false;
    });
  }

  openLoiDetail() {
    this._dialog.open(LoiDetailsComponent);
  }

  goToNextTab() {
    this.selectedTab.setValue(this.selectedTab.value + 1);
    this.isNextClicked = false;
    console.log(this.selectedTab.value);
  } 

  moveToPrev(){
    this.selectedTab.setValue(this.selectedTab.value - 1);
  }

  saveAgencyMoveToNext() {
    this.isNextClicked = true;
    this.saveAgency();
  }

  saveAgreementMoveToNext() {
    this.isNextClicked = true;
    this.saveAgreement();
  }

  saveCcnfCommisionMoveToNext() {
    this.isNextClicked = true;
    this.saveCcnfCommision();
  }

  saveAgency() {
    this.agencyForm.markAllAsTouched();
    this.agencyForm.markAsDirty();
    if (this.agencyForm.valid) {
      this.globalSharedSrv.isSpinnerActive.next(true);
      // setTimeout(() => {
        let agency: Agency = {
          agencyName: this.agencyForm.value.agency_agencyName,
          depot: this.agencyForm.value.agency_depot,
          district: this.agencyForm.value.agency_district,
          region: this.agencyForm.value.agency_region,
          state: this.agencyForm.value.agency_state,
          vendor: this.agencyForm.value.agency_vendor,
        };
        this.loiService.postAgency(agency).subscribe((res) => {
          console.log(res);
          this.globalSharedSrv.isSpinnerActive.next(false);
          this.isAgencyDataSaved = true;
          this.successNotification = true;
          setTimeout(() => {
            this.successNotification = false;
          }, 2000);
          if (this.isNextClicked) {
            this.goToNextTab();
          }
        }, (err) =>{
          this.globalSharedSrv.isSpinnerActive.next(false);
          console.log(err)
          this.failureNotification = true;
          setTimeout(() => {
            this.failureNotification = false;
          }, 3000);
        });
      // }, 2000);
    } else {
      this.isNextClicked = false;
    }
  }

  saveAgreement() {
    this.agreementForm.markAllAsTouched();
    this.agreementForm.markAsDirty();
    if (this.agreementForm.valid) {
      this.globalSharedSrv.isSpinnerActive.next(true);
      // setTimeout(() => {
        let agreement: Agreement= {
          startDate: this.agreementForm.value.agreement_startDate,
          endDate: this.agreementForm.value.agreement_endDate,
          billingCycle: this.agreementForm.value.agreement_billingCycle,
        };
        this.loiService.postAgreement(agreement).subscribe((res) => {
          console.log(res);
          this.globalSharedSrv.isSpinnerActive.next(false);
          this.isAgreementDataSaved = true;
          this.successNotification = true;
          setTimeout(() => {
            this.successNotification = false;
          }, 2000);
          if (this.isNextClicked) {
            this.goToNextTab();
          }
        }, (err) =>{
          this.globalSharedSrv.isSpinnerActive.next(false);
          console.log(err)
          this.failureNotification = true;
          setTimeout(() => {
            this.failureNotification = false;
          }, 3000);
        });
      // }, 2000);
    } else {
      this.isNextClicked = false;
    }
  }

  saveCcnfCommision() {
    this.ccnfCommisionForm.markAllAsTouched();
    this.ccnfCommisionForm.markAsDirty();
    if (this.ccnfCommisionForm.valid) {
      this.globalSharedSrv.isSpinnerActive.next(true);
      // setTimeout(() => {
        let ccnfCommision: CcnfCommision= {
          commisionRangeFrom: this.ccnfCommisionForm.value.ccnf_commisionRangeFrom,
          commisionRangeTo: this.ccnfCommisionForm.value.ccnf_commisionRangeTo,
        };
        this.loiService.postCcnfCommision(ccnfCommision).subscribe((res) => {
          console.log(res);
          this.globalSharedSrv.isSpinnerActive.next(false);
          this.isCCnFCommisionDataSaved = true;
          this.successNotification = true;
          setTimeout(() => {
            this.successNotification = false;
          }, 2000);
          if (this.isNextClicked) {
            this.goToNextTab();
          }
        }, (err) =>{
          this.globalSharedSrv.isSpinnerActive.next(false);
          console.log(err)
          this.failureNotification = true;
          setTimeout(() => {
            this.failureNotification = false;
          }, 3000);
        });
      // }, 2000);
    } else {
      this.isNextClicked = false;
    }
  }
}
