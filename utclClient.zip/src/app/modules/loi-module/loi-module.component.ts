import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-loi-module',
  templateUrl: './loi-module.component.html',
  styleUrls: ['./loi-module.component.css']
})
export class LoiModuleComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
