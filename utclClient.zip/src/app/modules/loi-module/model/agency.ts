export interface Agency{
    agencyName:string;
    vendor:string;
    state:string;
    region:string;
    depot:string;
    district:string;
}
export interface Agreement{
    startDate:Date;
    endDate:Date;
    billingCycle:string;
}
export interface CcnfCommision{
    commisionRangeFrom:number;
    commisionRangeTo:number;
}