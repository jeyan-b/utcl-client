export class LoginData {
  username : string;
  password : string;
}
